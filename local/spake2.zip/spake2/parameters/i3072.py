from ..params import _Params
from ..groups import I3072
# Params3072 has 128-bit security.
Params3072 = _Params(I3072)
